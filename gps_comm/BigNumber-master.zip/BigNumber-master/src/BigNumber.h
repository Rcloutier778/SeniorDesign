//
//  BigNumber.h
//  
//  Author:  Nick Gammon
//  Date:    7th January 2018.
//  Contributors: Paul Stoffregen, S. Downey
//  Version: 3.5
//  Released into the public domain.

#pragma once

#include "BigNumber/BigNumber.h"
